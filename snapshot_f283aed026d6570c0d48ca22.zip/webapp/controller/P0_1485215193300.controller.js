sap.ui.define(["sap/ui/core/mvc/Controller"], function(BaseController) {
	"use strict";

	return BaseController.extend("generated.app.controller.P0_1485215193300", {

	manageFilters: function(controlId, aggregationName, filterData) {
	   var view = this.getView();
	   var filters = [];
	   filterData.filters.forEach(function (filter) {
           var value1 = filter.type === 'Date' || filter.type === 'DateTime' ? new Date(filter.value1) : filter.value1;
           var value2 = null;
           if (filter.value2) {
               value2 = filter.type === 'Date' || filter.type === 'DateTime' ? new Date(filter.value2) : filter.value2;
           }
           var oFilter = new sap.ui.model.Filter(filter.path, filter.operator, value1, value2);
           filters.push(oFilter);
	   });
	   if (filterData.bindingParameters) {
	     filterData.bindingParameters.filters = filters;
	     view.byId(controlId).bindAggregation(aggregationName, filterData.bindingParameters);
	   }
	   else {
         view.byId(controlId).getBinding(aggregationName).filter(filters);
	   }
	},

	 onAfterRendering : function() {
	    var bindingParameters;
	    

        var filterData;
        
	 },

    onInit: function() {
        this._oDialog = this.getView().getContent()[0];
    },
    onExit: function() {
        this._oDialog.destroy();
    },
    setRouter: function(oRouter) {
        this.oRouter = oRouter;
    },

	});
}, /* bExport= */true);
